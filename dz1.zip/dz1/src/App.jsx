import React from 'react';
import { useDispatch, useSelector } from "react-redux";
import { increment, decrement, incrementTen, decrementTen, reset } from "./types/types.js";

const App = () => {
    const count = useSelector(state => state.count.count);
    const dispatch = useDispatch();

    return (
        <div>
            <button onClick={() => dispatch(decrementTen())}>-10</button>
            <button onClick={() => dispatch(decrement())}>-</button>
            <span>{count}</span>
            <button onClick={() => dispatch(reset())}>Reset</button>
            <button onClick={() => dispatch(increment())}>+</button>
            <button onClick={() => dispatch(incrementTen())}>+10</button>
        </div>
    );
};

export default App;
