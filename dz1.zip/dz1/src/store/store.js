import {combineReducers, createStore} from "redux";
import counterReducer from "../reducer/counterReducer";
const rootStore = combineReducers({
    count:counterReducer

})
const store = createStore(
    rootStore
)

export default store