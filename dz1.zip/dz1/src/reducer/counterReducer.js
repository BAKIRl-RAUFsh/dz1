const initialState = {
    count: 0,
};

const counterReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'INCREMENT':
            return {
                count: state.count + action.payload,
            };
        case 'DECREMENT':
            return {
                count: state.count > 0 ? state.count - 1 : 0,
            };
        case 'INCREMENT_TEN':
            return {
                count: state.count + action.payload,
            };
        case 'DECREMENT_TEN':
            return {
                count: state.count > 10 ? state.count - 10 : state.count,
            };
        case 'RESET':
            return {
                count: 0,
            };
        default:
            return state;
    }
};

export default counterReducer;
